# Shield Theme Maker

Application homebrew 3DS (y compris old 3DS) pour fabriquer un thème du menu HOME directement sur la console. Le code a été généré avec Codex.

> **Attention : l'audio reste expérimental.** Un thème contenant un BCSTM incorrect peut faire planter le menu HOME. Les corruptions observées jusqu'ici concernaient des thèmes avec audio. Les thèmes sans audio ont été davantage corrigés et ont fonctionné dans nos essais internes.

Version 0.2.11 : guide intégré réécrit pour débutants, avec une page par étape, des phrases lisibles sur l'écran inférieur et des commandes raccourcies pendant l'utilisation. Le guide s'affiche une fois après la mise à jour et reste accessible avec SELECT > Guide. La boucle audio reprend après les échantillons déjà entendus dans le fondu, pour éviter de répéter le début du morceau, notamment avec un fondu d'une seconde.

Version 0.2.10 : sept profils en stéréo PCM sans compression, de 8 kHz / 1 min 45 à 20 kHz / 41 s, par paliers de 2 kHz, avec 16 kHz / 52 s par défaut. Dans la liste des musiques, Y lit les 20 premières secondes pour reconnaître un fichier avant de le choisir. Après sélection, Y joue le passage choisi en boucle avec le fondu choisi ; Y ou B l'arrête. La recherche automatique de la meilleure fin peut encore raccourcir le passage de deux secondes au plus à l'export.

Version 0.2.9 : 55 secondes en stéréo PCM à 15 kHz, sans compression. Préécoute à la même fréquence, mais le fondu et la fin automatique ne sont appliqués que lors de la création. À la vérification, Y permet de choisir le nom du thème avec le clavier de la console. Les thèmes existants ne sont pas écrasés.

Version 0.2.6 : retour à 1 minute en stéréo à 14 kHz après un essai à 1 min 05 jugé trop dégradé. Le choix du cadrage est expliqué dans la version.

Version 0.2.4 : durée maximale portée à une minute en stéréo à 14 kHz.

Version 0.2.3 : préécoute du passage entier avec arrêt par Y ou B, mode de cadrage « prolonger » qui répète les pixels du bord sans flou, et affichage stabilisé de l'écran inférieur. La création de thèmes **sans audio** a été largement travaillée et corrigée en interne. La conversion et l'utilisation d'un thème **avec audio restent expérimentales**.

## Pourquoi ce projet existe

Nous voulions qu'une personne puisse créer son thème 3DS **sur sa propre console**, avec deux images et, si elle le souhaite, une musique. Nous avons beaucoup repris le cadrage pour qu'il soit compréhensible et libre : déplacer l'image, zoomer, conserver l'image entière ou prolonger ses bords sans flou. Nous avons aussi dû réduire le temps de chargement et stabiliser l'affichage pour une Old 3DS.

L'audio a été la partie la plus difficile. **Jusqu'à présent, les corruptions de données de thème observées concernaient des thèmes contenant un audio** : certaines conversions faisaient planter le menu HOME, d'autres écourtaient fortement la musique. La création sans audio a été beaucoup corrigée et fonctionne correctement dans nos essais internes. La création actuelle vérifie la structure du BCSTM avant d'exporter un thème avec audio, permet d'écouter le passage choisi et préserve presque toute sa durée en mode automatique. **J'ai réussi à faire fonctionner un thème avec audio sur une 3DS réelle, sans corruption lors de cet essai.** Je dois encore améliorer le système audio et vérifier la durée, la boucle et la compatibilité sur davantage de thèmes et de consoles.

Le projet est gratuit et son code a été généré avec Codex. Les retours de la communauté nous aident à corriger les difficultés que rencontrent les personnes qui ne programment pas.

## Exemples partagés par Shield-77

Un thème créé avec l'application :

<img width="2296" height="4080" alt="Thème créé avec Shield Theme Maker" src="https://github.com/user-attachments/assets/d6b95913-4bf7-4e9b-8d55-d39656115922" />

Son aperçu dans Anemone3DS :

<img width="864" height="1536" alt="Aperçu d'un thème dans Anemone3DS" src="https://github.com/user-attachments/assets/147b46e6-a45a-4fba-9144-f70c4d5faf89" />

## Installation CIA

Copier `shield_theme_maker.cia` sur la carte SD puis l'installer avec un outil d'installation de CIA sur une 3DS équipée de CFW. L'icône et la bannière apparaissent sur le menu HOME. Le splash de l'application est inclus dans la RomFS du CIA.

## Installation 3DSX (alternative)

Copier le contenu du dossier `3ds/shield_theme_maker` de l'archive de distribution dans le même dossier sur la carte SD, puis lancer `shield_theme_maker.3dsx` depuis Homebrew Launcher. Une console capable de lancer des homebrews est nécessaire.

## Guide pour débuter

Le guide de huit pages apparaît au premier lancement de cette version. Pour le revoir plus tard, appuyer sur **SELECT**, puis choisir **Guide**. Dans le guide, **A** avance et **B** revient à la page précédente.

### 1. Trouver les deux images

Les images PNG et JPG peuvent être **à la racine de la carte SD ou dans un dossier**. L'application affiche d'abord les fichiers les plus récents ; maintenir haut ou bas accélère le défilement.

1. À l'étape « Image du haut », déplacer la sélection avec **haut/bas**. **A** ouvre un dossier. Sur une image, **Y** la montre sur l'écran supérieur avant de la choisir ; **A** la choisit.
2. Faire la même chose à l'étape « Image du bas ». Le titre de l'étape indique toujours l'écran concerné. **B** remonte d'un dossier ; à la racine, **B** revient à l'étape précédente.

### 2. Cadrer chaque image

Regarder **l'écran supérieur** : le bord **cyan** indique que l'on cadre l'image du haut ; le bord **jaune**, celle du bas. La croix directionnelle déplace le cadrage. **L** éloigne l'image et **R** la rapproche. On peut aussi toucher la petite carte de cadrage sur l'écran inférieur. **Y** propose un centrage automatique, sans l'imposer.

**X** change la façon de cadrer :

| Mode | Ce que l'on obtient |
| --- | --- |
| Remplir | L'image couvre tout l'écran ; des bords peuvent être coupés. |
| Entière | Toute l'image reste visible ; des bandes peuvent apparaître. |
| Prolonger | Les pixels du bord sont répétés pour remplir l'espace restant. |

**A** valide le cadrage affiché et passe à l'image suivante. **B** revient en arrière. L'aperçu rapide peut paraître moins fin sur Old 3DS ; le thème exporté utilise le rendu complet.

### 3. Choisir une musique, ou continuer sans musique

La musique est facultative : à l'étape « Musique », **X** continue sans audio. Sinon, sélectionner un MP3, un OGG ou un BCSTM. **Y** lit jusqu'à 20 secondes du fichier surligné pour le reconnaître ; **Y** ou **B** arrête l'extrait. Certains BCSTM importés ne peuvent pas être préécoutés, mais restent sélectionnables s'ils passent la vérification.

**A** choisit le fichier. Même si la musique dure sept minutes, le thème n'utilise qu'un **passage** de la durée indiquée à l'écran suivant.

### 4. Régler le passage et la qualité

**Gauche/droite change toujours la qualité.** Plus la fréquence est élevée, plus le son peut être clair, mais plus le passage maximal est court. Le réglage par défaut est **16 kHz / 52 s** ; tous les profils restent en stéréo PCM sans compression.

| Qualité | Durée maximale |
| --- | --- |
| 8 kHz | 1 min 45 s |
| 10 kHz | 1 min 24 s |
| 12 kHz | 1 min 10 s |
| 14 kHz | 1 min |
| 16 kHz | 52 s |
| 18 kHz | 46 s |
| 20 kHz | 41 s |

Le passage commence au début du fichier par défaut. Pour prendre une autre partie d'un long morceau, toucher les deux barres : **D** règle le début et **F** la fin. **X** alterne entre la fin choisie automatiquement et le choix manuel. **L/R** change la durée du fondu, affichée en secondes : ce fondu relie la fin du passage à son début.

**Y** écoute le passage en boucle avec le fondu choisi ; **Y** ou **B** arrête la lecture. Un deuxième appui sur **B** revient à l'étape précédente. La préécoute utilise la même fréquence que l'export. En mode automatique, l'export peut choisir une fin jusqu'à deux secondes plus tôt pour améliorer la boucle.

### 5. Créer et retrouver le thème

**X** choisit une archive ZIP ou un dossier classique. Les deux sont placés dans `sdmc:/themes/` : le dossier existant est réutilisé. **Y** choisit l'image du haut ou du bas pour l'**icône**, celle qui aide à retrouver le thème dans Anemone. L'icône est distincte du grand aperçu du thème.

Sur l'écran de vérification, relire les choix. **Y** permet de donner un nom au thème ; **B** revient corriger un choix ; **A** démarre la création. Suivre la barre de progression sur l'écran supérieur et garder la console éveillée jusqu'au message de fin. Un thème portant déjà ce nom reste intact : un suffixe est ajouté au nouveau.

Le thème créé apparaît dans `/themes/`. Il peut ensuite être choisi dans Anemone. Shield Theme Maker prépare les fichiers du thème ; il ne l'applique pas directement au menu HOME.

### En cas de doute

- **SELECT** ouvre les options **Langue** et **Guide** depuis les écrans de choix.
- **B** arrête d'abord une préécoute ; un deuxième appui revient en arrière.
- Si un audio est refusé à la création, revenir le corriger ou créer le thème sans musique.
- **START** ferme l'application. Attendre la fin de la création avant de quitter.

### Mode automatique

Placer `haut.png` ou `top.png`, et `bas.png` ou `bottom.png`, dans `sdmc:/3ds/ShieldThemeMaker/input/` (les extensions `.jpg` et `.jpeg` fonctionnent aussi). Ajouter éventuellement `bgm.bcstm`, `bgm.ogg` ou `bgm.mp3` au même endroit. À la première étape, appuyer sur **X** pour détecter les fichiers et préparer le thème. Le dossier d'entrée est créé au premier lancement. Les photos prises avec la console restent accessibles dans `sdmc:/DCIM/` via le navigateur intégré.

Anemone3DS peut ensuite appliquer le thème créé depuis sa liste. Shield Theme Maker exporte le thème et n'écrit pas directement dans les données du menu HOME.

## Limites actuelles

- Images PNG/JPEG jusqu'à 2,4 millions de pixels et 4096 pixels par côté, afin de limiter l'usage de mémoire sur old 3DS.
- Les BCSTM importés doivent passer une validation de structure et tenir dans la limite de 0x337000 octets du cache BGM du menu HOME. Les OGG/MP3 sont décodés au fil de l'eau et enregistrés en PCM16 stéréo ; pour une piste plus longue, choisir un passage. Le WAV n'est pas accepté. Un MP3 ne produit pas de `bgm.ogg` : la version actuelle n'embarque pas d'encodeur OGG.
- Fond statique, sans animation ni sons d'interface personnalisés.
- Le redimensionnement utilise une correspondance entière préparée une fois par axe, avec interpolation ou moyenne selon l'échelle. Les binaires sont compilés avec devkitPro ; la vitesse et le fonctionnement sur console physique restent à vérifier.

## Compilation

Installer devkitPro avec devkitARM et libctru, définir `DEVKITPRO` et `DEVKITARM`, puis exécuter `make` dans ce dossier. La compilation produit `shield_theme_maker.elf` et `shield_theme_maker.3dsx` et intègre `romfs/splash.png`. L'icône est générée depuis `icon.png`.

Pour produire le CIA, installer [makerom](https://github.com/3DSGuy/Project_CTR/releases) et [bannertool](https://github.com/carstene1ns/3ds-bannertool/releases), puis exécuter depuis ce dossier :

```sh
bannertool makebanner -i banner.png -a banner.wav -o banner.bnr
makerom -f cia -o shield_theme_maker.cia -DAPP_ENCRYPTED=false -rsf shield.rsf -target t -ver 1025 -exefslogo -elf shield_theme_maker.elf -icon shield_theme_maker.smdh -banner banner.bnr
```

`shield.rsf` configure le mode Legacy compatible old 3DS. La bannière Homebrew Launcher est `shield_theme_maker-banner-fullscreen.png`.

## Sources techniques

Le code propre à Shield Theme Maker est publié sous **GPLv3** (`LICENSE`). Les composants tiers conservent leurs licences respectives. La police embarquée Atkinson Hyperlegible est sous **SIL Open Font License 1.1** (`LICENSE-AtkinsonHyperlegible.txt`). Le nom Shield identifie le projet d'origine ; une modification doit être présentée comme telle et ne doit pas se faire passer pour une version officielle de Shield-77.

- Format du thème : [3dbrew Home Menu/Themes](https://www.3dbrew.org/wiki/Home_Menu/Themes/).
- Outils et structure de référence : [Kame Tools](https://gitlab.com/beelzy/kame-tools).
- Décodeur PNG/JPEG : `source/stb_image.h`, de Sean Barrett, sous licence MIT ou domaine public selon le choix proposé dans son en-tête.
- Écriture PNG : `source/stbi_image_write.[ch]`, de Sean Barrett, domaine public.
- Décodage MP3 : `source/minimp3*.h`, de Lieff, CC0 (`LICENSE-minimp3.txt`). Décodage OGG : libvorbisidec/Tremor fournie par devkitPro.

Le visuel de l'application provient de l'image fournie pour ce projet : `https://files.catbox.moe/7rtp80.png`.
